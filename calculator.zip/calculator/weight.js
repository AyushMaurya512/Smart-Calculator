var input = document.getElementById('input');
var result = document.getElementById('result');
var inputType = document.getElementById('inputType');
var input = document.getElementById('input');
var resultType = document.getElementById('resultType');
var inputTypeValue,resultTypeValue;
input.addEventListener("keyup",myResult);
inputType.addEventListener("change",myResult);
resultType.addEventListener("change",myResult);

inputTypeValue = inputType.value;
resultTypeValue = resultType.value;

function myResult(){
   // result.value = input.value;
   inputTypeValue = inputType.value;
   resultTypeValue = resultType.value;
   if(inputTypeValue === "tonne" && resultTypeValue==="kilogram"){
    result.value = Number(input.value) * 1000;
  }else if(inputTypeValue === "tonne" && resultTypeValue==="gram"){
   result.value = Number(input.value) * 1000000;
  }else if(inputTypeValue === "tonne" && resultTypeValue==="milligram"){
    result.value = Number(input.value) * 1000000000;
  }else if(inputTypeValue === "tonne" && resultTypeValue==="microgram"){
   result.value = Number(input.value) * 1000000000000;
  }else if(inputTypeValue === "tonne" && resultTypeValue==="tonne"){ 
   result.value = input.value
  }

     if(inputTypeValue === "kilogram" && resultTypeValue==="tonne"){
    result.value = Number(input.value) * 0.001;
  }else if(inputTypeValue === "kilogram" && resultTypeValue==="gram"){
   result.value = Number(input.value) * 1000;
  }else if(inputTypeValue === "kilogram" && resultTypeValue==="milligram"){
    result.value = Number(input.value) * 1000000;
  }else if(inputTypeValue === "kilogram" && resultTypeValue==="microgram"){
   result.value = Number(input.value) * 1000000000;
  }else if(inputTypeValue === "kilogram" && resultTypeValue==="kilogram"){ 
   result.value = input.value
  }


     if(inputTypeValue === "gram" && resultTypeValue==="tonne"){
    result.value = Number(input.value) * 0.000001;
  }else if(inputTypeValue === "gram" && resultTypeValue==="kilogram"){
   result.value = Number(input.value) * 0.001;
  }else if(inputTypeValue === "gram" && resultTypeValue==="milligram"){
    result.value = Number(input.value) * 1000;
  }else if(inputTypeValue === "gram" && resultTypeValue==="microgram"){
   result.value = Number(input.value) * 1000000;
  }else if(inputTypeValue === "gram" && resultTypeValue==="gram"){ 
   result.value = input.value
  }
     if(inputTypeValue === "milligram" && resultTypeValue==="tonne"){
    result.value = Number(input.value) * 0.000000001;
  }else if(inputTypeValue === "milligram" && resultTypeValue==="kilogram"){
   result.value = Number(input.value) * 0.000001;
  }else if(inputTypeValue === "milligram" && resultTypeValue==="gram"){
    result.value = Number(input.value) * 0.001;
  }else if(inputTypeValue === "milligram" && resultTypeValue==="microgram"){
   result.value = Number(input.value) * 1000;
  }else if(inputTypeValue === "milligram" && resultTypeValue==="milligram"){ 
   result.value = input.value
  }


     if(inputTypeValue === "microgram" && resultTypeValue==="tonne"){
    result.value = Number(input.value) * 0.000000000001;
  }else if(inputTypeValue === "microgram" && resultTypeValue==="kilogram"){
   result.value = Number(input.value) * 0.000000001;
  }if(inputTypeValue === "microgram" && resultTypeValue==="gram"){
    result.value = Number(input.value) * 0.000001;
  }else if(inputTypeValue === "microgram" && resultTypeValue==="milligram"){
   result.value = Number(input.value) * 0.001;
  }else if(inputTypeValue === "microgram" && resultTypeValue==="microgram"){ 
   result.value = input.value
  }
}