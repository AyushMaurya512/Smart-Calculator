var input = document.getElementById('input');
var result = document.getElementById('result');
var inputType = document.getElementById('inputType');
var input = document.getElementById('input');
var resultType = document.getElementById('resultType');
var inputTypeValue,resultTypeValue;
input.addEventListener("keyup",myResult);
inputType.addEventListener("change",myResult);
resultType.addEventListener("change",myResult);

inputTypeValue = inputType.value;
resultTypeValue = resultType.value;

function myResult(){
   // result.value = input.value;
   inputTypeValue = inputType.value;
   resultTypeValue = resultType.value;
   if(inputTypeValue === "millisecond" && resultTypeValue==="second"){
    result.value = Number(input.value) * 0.001;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="minute"){
   result.value = Number(input.value) / 60000;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="hour"){
    result.value = Number(input.value) / 3600000;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="day"){
   result.value = Number(input.value) / 86400000;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="week"){ 
   result.value = Number(input.value) / 604800000;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="month"){ 
   result.value = Number(input.value) / 2592000000;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="year"){ 
   result.value = Number(input.value) / 31536000000;
  }else if(inputTypeValue === "millisecond" && resultTypeValue==="millisecond"){ 
   result.value = input.value
  }
    
  if(inputTypeValue === "second" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 1000;
  }else if(inputTypeValue === "second" && resultTypeValue==="minute"){
   result.value = Number(input.value) / 60;
  }else if(inputTypeValue === "second" && resultTypeValue==="hour"){
   result.value = Number(input.value) /3600;
  }else if(inputTypeValue === "second" && resultTypeValue==="day"){
   result.value = Number(input.value) /86400;
  }else if(inputTypeValue === "second" && resultTypeValue==="week"){ 
   result.value = Number(input.value) /604800;
  }else if(inputTypeValue === "second" && resultTypeValue==="month"){ 
   result.value = Number(input.value) /2592000;
  }else if(inputTypeValue === "second" && resultTypeValue==="year"){ 
   result.value = Number(input.value) /31536000;
  }else if(inputTypeValue === "second" && resultTypeValue==="second"){ 
   result.value = input.value
  }
   
  if(inputTypeValue === "minute" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 60000;
  }else if(inputTypeValue === "minute" && resultTypeValue==="second"){
   result.value = Number(input.value) * 60;
  }else if(inputTypeValue === "minute" && resultTypeValue==="hour"){
    result.value = Number(input.value) /60;
  }else if(inputTypeValue === "minute" && resultTypeValue==="day"){
   result.value = Number(input.value) /1440;
  }else if(inputTypeValue === "minute" && resultTypeValue==="week"){ 
   result.value = Number(input.value) /10080;
  }else if(inputTypeValue === "minute" && resultTypeValue==="month"){ 
   result.value = Number(input.value) /43800;
  }else if(inputTypeValue === "minute" && resultTypeValue==="year"){ 
   result.value = Number(input.value) /515600;
  }else if(inputTypeValue === "minute" && resultTypeValue==="minute"){ 
   result.value = input.value
  }
  
  if(inputTypeValue === "hour" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 3600000;
  }else if(inputTypeValue === "hour" && resultTypeValue==="second"){
   result.value = Number(input.value) * 3600;
  }else if(inputTypeValue === "hour" && resultTypeValue==="minute"){
    result.value = Number(input.value) * 60;
  }else if(inputTypeValue === "hour" && resultTypeValue==="day"){
   result.value = Number(input.value) / 24;
  }else if(inputTypeValue === "hour" && resultTypeValue==="week"){ 
   result.value = Number(input.value) / 168;
  }else if(inputTypeValue === "hour" && resultTypeValue==="month"){ 
   result.value = Number(input.value) / 730;
  }else if(inputTypeValue === "hour" && resultTypeValue==="year"){ 
   result.value = Number(input.value) / 8760;
  }else if(inputTypeValue === "hour" && resultTypeValue==="hour"){ 
   result.value = input.value
  }
  
  if(inputTypeValue === "day" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 86400000;
  }else if(inputTypeValue === "day" && resultTypeValue==="second"){
   result.value = Number(input.value) * 86400;
  }else if(inputTypeValue === "day" && resultTypeValue==="minute"){
    result.value = Number(input.value) * 1440;
  }else if(inputTypeValue === "day" && resultTypeValue==="hour"){
   result.value = Number(input.value) * 24;
  }else if(inputTypeValue === "day" && resultTypeValue==="week"){ 
   result.value = Number(input.value) / 7;
  }else if(inputTypeValue === "day" && resultTypeValue==="month"){ 
   result.value = Number(input.value) / 30.417;
  }else if(inputTypeValue === "day" && resultTypeValue==="year"){ 
   result.value = Number(input.value) / 365;
  }else if(inputTypeValue === "day" && resultTypeValue==="day"){ 
   result.value = input.value
  }
  
  if(inputTypeValue === "week" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 604800000;
  }else if(inputTypeValue === "week" && resultTypeValue==="second"){
   result.value = Number(input.value) * 604800;
  }else if(inputTypeValue === "week" && resultTypeValue==="minute"){
    result.value = Number(input.value) * 10080;
  }else if(inputTypeValue === "week" && resultTypeValue==="hour"){
   result.value = Number(input.value) * 168;
  }else if(inputTypeValue === "week" && resultTypeValue==="day"){ 
   result.value = Number(input.value) * 7;
  }else if(inputTypeValue === "week" && resultTypeValue==="month"){ 
   result.value = Number(input.value) / 4.345;
  }else if(inputTypeValue === "week" && resultTypeValue==="year"){ 
   result.value = Number(input.value) / 52.143;
  }else if(inputTypeValue === "week" && resultTypeValue==="week"){ 
   result.value = input.value
  }  
  
  if(inputTypeValue === "month" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 2628000000;
  }else if(inputTypeValue === "month" && resultTypeValue==="second"){
   result.value = Number(input.value) * 2628000;
  }else if(inputTypeValue === "month" && resultTypeValue==="minute"){
    result.value = Number(input.value) * 43800;
  }else if(inputTypeValue === "month" && resultTypeValue==="hour"){
   result.value = Number(input.value) * 730;
  }else if(inputTypeValue === "month" && resultTypeValue==="day"){ 
   result.value = Number(input.value) * 30.417;
  }else if(inputTypeValue === "month" && resultTypeValue==="week"){ 
   result.value = Number(input.value) * 4.345;
  }else if(inputTypeValue === "month" && resultTypeValue==="year"){ 
   result.value = Number(input.value) / 12;
  }else if(inputTypeValue === "month" && resultTypeValue==="month"){ 
   result.value = input.value
  }   

  if(inputTypeValue === "year" && resultTypeValue==="millisecond"){
    result.value = Number(input.value) * 31536000000;
  }else if(inputTypeValue === "year" && resultTypeValue==="second"){
   result.value = Number(input.value) * 31536000;
  }else if(inputTypeValue === "year" && resultTypeValue==="minute"){
    result.value = Number(input.value) * 525600;
  }else if(inputTypeValue === "year" && resultTypeValue==="hour"){
   result.value = Number(input.value) * 8760;
  }else if(inputTypeValue === "year" && resultTypeValue==="day"){ 
   result.value = Number(input.value) * 365;
  }else if(inputTypeValue === "year" && resultTypeValue==="week"){ 
   result.value = Number(input.value) * 52.143;
  }else if(inputTypeValue === "year" && resultTypeValue==="month"){ 
   result.value = Number(input.value) * 12;
  }else if(inputTypeValue === "year" && resultTypeValue==="year"){ 
   result.value = input.value
  }     
}